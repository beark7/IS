-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Giu 16, 2023 alle 21:29
-- Versione del server: 10.4.24-MariaDB
-- Versione PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `appannunci`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `annuncio`
--

CREATE TABLE `annuncio` (
  `IDAnnuncio` int(11) NOT NULL,
  `IDInserzionista` int(11) DEFAULT NULL,
  `prezzo` float DEFAULT NULL,
  `dataInserimento` varchar(255) DEFAULT NULL,
  `cap` varchar(255) DEFAULT NULL,
  `numMetriQuadri` float DEFAULT NULL,
  `numVani` int(11) DEFAULT NULL,
  `descrizione` varchar(255) DEFAULT NULL,
  `stato` varchar(255) DEFAULT NULL,
  `IDFoto` int(11) DEFAULT NULL,
  `tipologia` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `annuncio`
--

INSERT INTO `annuncio` (`IDAnnuncio`, `IDInserzionista`, `prezzo`, `dataInserimento`, `cap`, `numMetriQuadri`, `numVani`, `descrizione`, `stato`, `IDFoto`, `tipologia`) VALUES
(1, 1, 150000, '2023-06-01', '80100', 75.5, 3, 'Appartamento spazioso con vista panoramica', 'NUOVO', NULL, 'VENDITA'),
(2, 2, 1200, '2023-06-02', '80100', 65.75, 4, 'Villetta a schiera con giardino privato', 'NUOVO', NULL, 'AFFITTO'),
(3, 1, 300000, '2023-06-03', '80100', 120, 3, 'Casa indipendente con terrazza panoramica', 'RISTRUTTURATO', NULL, 'VENDITA'),
(4, 2, 800, '2023-06-04', '80100', 45, 4, 'Monolocale completamente arredato', 'NUOVO', NULL, 'AFFITTO'),
(5, 1, 500000, '2023-06-05', '80100', 150, 3, 'Casa familiare con ampio giardino', 'NUOVO', NULL, 'VENDITA'),
(6, 2, 180000, '2023-06-06', '80100', 80, 4, 'Appartamento ristrutturato in zona centrale', 'RISTRUTTURATO', NULL, 'VENDITA'),
(7, 1, 900, '2023-06-07', '80100', 50, 3, 'Bilocale con balcone in quartiere tranquillo', 'NUOVO', NULL, 'AFFITTO'),
(8, 2, 250000, '2023-06-08', '80100', 110, 4, 'Casa a schiera con ampio garage', 'RISTRUTTURATO', NULL, 'VENDITA'),
(9, 1, 1000, '2023-06-09', '80100', 60, 3, 'Appartamento luminoso con vista sul parco', 'RISTRUTTURATO', NULL, 'AFFITTO'),
(10, 2, 350000, '2023-06-10', '80100', 130, 4, 'Villa con piscina e giardino curato', 'NUOVO', NULL, 'VENDITA');

-- --------------------------------------------------------

--
-- Struttura della tabella `foto`
--

CREATE TABLE `foto` (
  `IDFoto` int(11) NOT NULL,
  `IDAnnuncio` int(11) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `foto`
--

INSERT INTO `foto` (`IDFoto`, `IDAnnuncio`, `url`) VALUES
(1, 1, 'foto1.jpg'),
(2, 1, 'foto2.jpg'),
(3, 1, 'foto3.jpg'),
(4, 1, 'foto4.jpg'),
(5, 1, 'foto5.jpg'),
(6, 1, 'foto6.jpg'),
(7, 1, 'foto7.jpg'),
(8, 1, 'foto8.jpg'),
(9, 1, 'foto9.jpg'),
(10, 2, 'foto10.jpg'),
(11, 2, 'foto11.jpg'),
(12, 2, 'foto12.jpg'),
(13, 3, 'foto13.jpg'),
(14, 4, 'foto14.jpg'),
(15, 5, 'foto15.jpg'),
(16, 6, 'foto16.jpg'),
(17, 7, 'foto17.jpg'),
(18, 8, 'foto18.jpg'),
(19, 9, 'foto19.jpg'),
(20, 10, 'foto20.jpg');

-- --------------------------------------------------------

--
-- Struttura della tabella `inserzionista`
--

CREATE TABLE `inserzionista` (
  `IDInserzionista` int(11) NOT NULL,
  `IDAnnuncio` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telefono` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `inserzionista`
--

INSERT INTO `inserzionista` (`IDInserzionista`, `IDAnnuncio`, `username`, `password`, `email`, `telefono`) VALUES
(1, 1, 'inserzionista1', 'password1', 'inserzionista1@example.com', '3471283271'),
(2, 2, 'inserzionista2', 'password2', 'inserzionista2@example.com', '3296754291');

-- --------------------------------------------------------

--
-- Struttura della tabella `newsletter`
--

CREATE TABLE `newsletter` (
  `IDNewsletter` int(11) NOT NULL,
  `IDUtenteNewsletter` int(11) DEFAULT NULL,
  `giornoInvio` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struttura della tabella `utentenewsletter`
--

CREATE TABLE `utentenewsletter` (
  `IDUtenteNewsletter` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `isNewsletter` bit(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `annuncio`
--
ALTER TABLE `annuncio`
  ADD PRIMARY KEY (`IDAnnuncio`);

--
-- Indici per le tabelle `foto`
--
ALTER TABLE `foto`
  ADD PRIMARY KEY (`IDFoto`);

--
-- Indici per le tabelle `inserzionista`
--
ALTER TABLE `inserzionista`
  ADD PRIMARY KEY (`IDInserzionista`);

--
-- Indici per le tabelle `newsletter`
--
ALTER TABLE `newsletter`
  ADD PRIMARY KEY (`IDNewsletter`);

--
-- Indici per le tabelle `utentenewsletter`
--
ALTER TABLE `utentenewsletter`
  ADD PRIMARY KEY (`IDUtenteNewsletter`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `annuncio`
--
ALTER TABLE `annuncio`
  MODIFY `IDAnnuncio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
