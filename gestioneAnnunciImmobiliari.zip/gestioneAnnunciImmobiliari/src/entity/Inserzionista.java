package entity;

/**
 * Classe dell'entità Inserzionista
 * @author Pasquale Schioppa
 * @version 14/06/2023
 *
 */

public class Inserzionista extends UtenteRegistrato {
	
    private String telefono;
    private int idIns;
    
    /**
     * Costruttore classe Inserzionista della classe child di "UtenteRegistrato" 
     * @param username parametro per il nome utente
     * @param password parametro per la password
     * @param email parametro per l'email
     * @param telefono parametro per il telefono
     * @param idIns parametro per l'id inserzionista
     */
    public Inserzionista(String username, String password, String email, String telefono, int idIns) {
        super(username, password, email);
        this.telefono = telefono;
        this.idIns = idIns;
    }
   
    /**
     * Getter telefono
     * @return telefono inserzionista
     */
    public String getTelefono() {
        return telefono;
    }
    
    /**
     * Setter telefono
     * @param telefono come paramentro di input della funzione
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    
    /**
     * Getter id inserzionista
     * @return idIns
     */
    public int getIdIns() {
        return idIns;
    }
    
    /**
     * Setter inserzionsta, paramentro di input id inserzionista
     * @param idIns
     */
    public void setIdIns(int idIns) {
        this.idIns = idIns;
    }
}
