package entity;

/**
 * Classe dell'entità Newsletter
 * @author Pasquale Schioppa
 * @version 14/06/2023
 *
 */

public class Newsletter  {
    private String giornoInvio;
    private String content;
    
    /**
     * Costruttore classe Newsletter
     * @param giornoInvio parametro giorno di invio della newsletter
     * @param content parametro per il content della newsletter
     */
    public Newsletter(String giornoInvio, String content) {
        
        this.giornoInvio = giornoInvio;
        this.content = content;
    }
    
    /**
     * Getter giorno invio
     * @return giornoInvio restituisce il giorno invio newsletter
     */
    public String getGiornoInvio() {
        return giornoInvio;
    }

    /**
     * Setter giorno invio
     * @param giornoInvio parametro di input
     */
    public void setGiornoInvio(String giornoInvio) {
        this.giornoInvio = giornoInvio;
    }

    /**
     * Getter del content newsletter
     * @return content restituisce il content della newsletter
     */
    public String getContent() {
        return content;
    }
    
    /**
     * Setter content newsletter
     * @param content parametro di input
     */
    public void setContent(String content) {
        this.content = content;
    }
}
