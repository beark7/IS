package entity;

/**
 * Classe dell'entità Annuncio
 * @author Pasquale Schioppa
 * @version 14/06/2023
 *
 */

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class Annuncio {
    private int idAnnuncio;
    private int idInserzionista;
    private float prezzo;
    private Date dataInserimento;
    private String cap;
    private float numMetriQuadri;
    private int numVani;
    private String descrizione;
	private Stato stato;
    private List<Foto> foto;
    private Tipologia tipologia;
    
    /**
     * Costruttore della classe Annuncio
     * @param idAnnuncio parametro di input id annuncio
     * @param idInserzionista parametro di input id inserzionista
     * @param prezzo parametro di input prezzo
     * @param dataInserimento parametro di input data inserimento
     * @param cap parametro di input di cap
     * @param numMetriQuadri parametro di input dei metri quadri
     * @param numVani parametro di input del numero dei vani
     * @param descrizione parametro di input della descrizione
     * @param stato parametro di input dello stato
     * @param foto parametro di input foto, lista di tipo Foto
     * @param tipologiaValue parametro di input della tipologia
     */
    public Annuncio(int idAnnuncio, int idInserzionista, float prezzo, Date dataInserimento, String cap, float numMetriQuadri, int numVani,
                    String descrizione, Stato stato, List<Foto> foto, Tipologia tipologiaValue) {
        this.idAnnuncio = idAnnuncio;
        this.idInserzionista = idInserzionista;
        this.prezzo = prezzo;
        this.dataInserimento = dataInserimento;
        this.cap = cap;
        this.numMetriQuadri = numMetriQuadri;
        this.numVani = numVani;
        this.descrizione = descrizione;
        this.stato = stato;
        this.foto = foto;
        this.tipologia = tipologiaValue;
    }
    
    /**
     * Getter id inserzionista
     * @return idInserzionista restituisce l'id inserzionista
     */
    public int getIdInserzionista() {
		return idInserzionista;
	}

    /**
     * Setter id inserzionista
     * @param idInserzionista paramentro di input
     */
	public void setIdInserzionista(int idInserzionista) {
		this.idInserzionista = idInserzionista;
	}

	/**
	 * Getter della lista foto
	 * @return foto restituisce una lista di foto
	 */
	public List<Foto> getFoto() {
		return foto;
	}

	/**
	 * Setter della lista foto
	 * @param foto parametro di input, una lista di Foto
	 */
	public void setFoto(List<Foto> foto) {
		this.foto = foto;
	}

	/**
	 * Variante del costruttore Annuncio
	 * @param idAnnuncio parametro di input
	 */
	public Annuncio(int idAnnuncio) {
		this.idAnnuncio = idAnnuncio;
	}
	
	/**
	 * Getter dell'id annuncio
	 * @return idAnnuncio restituisce l'id annuncio
	 */
	public int getIdAnnuncio() {
        return idAnnuncio;
    }
	
	/**
	 * Setter dell'id annuncio
	 * @param idAnnuncio parametro di input
	 */
    public void setIdAnnuncio(int idAnnuncio) {
        this.idAnnuncio = idAnnuncio;
    }
    
    /**
     * Getter del prezzo
     * @return prezzo restituisce il prezzo
     */
    public float getPrezzo() {
        return prezzo;
    }
    
    /**
     * Setter del prezzo
     * @param prezzo parametro di input
     */
    public void setPrezzo(float prezzo) {
        this.prezzo = prezzo;
    }
    
    /**
     * Getter della data di inserimento
     * @return dataInserimento restituisce la data di inserimento annuncio
     */
    public Date getDataInserimento() {
        return dataInserimento;
    }
    
    /**
     * Setter della data inserimento
     * @param dataInserimento parametro di input
     */
    public void setDataInserimento(Date dataInserimento) {
        this.dataInserimento = dataInserimento;
    }
    
    /**
     * Getter del cap
     * @return cap restituisce il cap
     */
    public String getCap() {
        return cap;
    }
    
    /**
     * Setter del cap
     * @param cap parametro di input
     */
    public void setCap(String cap) {
        this.cap = cap;
    }
    
    /**
     * Getter dei metri quadri
     * @return numMetriQuadri restituisce i metri quadri
     */
    public float getNumMetriQuadri() {
        return numMetriQuadri;
    }
    
    /**
     * Setter dei metri quadri
     * @param numMetriQuadri parametro di input
     */
    public void setNumMetriQuadri(float numMetriQuadri) {
        this.numMetriQuadri = numMetriQuadri;
    }
    
    /**
     * Getter dei numero vani
     * @return numVani restituisce il numero dei vani
     */
    public int getNumVani() {
        return numVani;
    }
    
    /**
     * Setter dei numero dei vani
     * @param numVani parametro di input
     */
    public void setNumVani(int numVani) {
        this.numVani = numVani;
    }

    /**
     * Getter della descrizione
     * @return descrizione restituisce la descrizione
     */
    public String getDescrizione() {
        return descrizione;
    }
    
    /**
     * Setter della descrizione
     * @param descrizione parametro di input
     */
    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }
    
    /**
	 * Getter della tipologia
	 * @return tipologia restituisce tipologia
	 */
    public Tipologia getTipologia() {
    	return tipologia;
    }
    
    /**
	 * Setter della tipologia
	 * @param tipo paramentro di input
	 */
    public void setTipologia(Tipologia tipo) {
    	this.tipologia = tipo;
    }
    
    /**
     * Getter dello stato
     * @return stato restituisce lo stato
     */
    public Stato getStato() {
    	return stato;
    }
    
    /**
     * Setter dello stato
     * @param st parametro di input
     */
    public void setStato(Stato st) {
    	this.stato = st;
    }
}
