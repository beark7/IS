package entity;

/**
 * Classe dell'entità UtenteNewsletter parent della classe Newsletter
 * @author Pasquale Schioppa
 * @version 14/06/2023
 *
 */

public class UtenteNewsletter extends UtenteRegistrato {
    private boolean isNewsletter;
    
    /**
     * Costruttore classe UtenteNewsletter (child) della classe parent "UtenteRegistrato" 
     * @param username parametro per il nome utente
     * @param password parametro per la password
     * @param email parametro per l'email
     * @param isNewsletter parametro per isNewsletter
     */
    public UtenteNewsletter(String username, String password, String email, boolean isNewsletter) {
        super(username, password, email);
        this.isNewsletter = isNewsletter;
    }
    
    /**
     * Getter Newsletter
     * @return isNewsletter restituisce il valore booleano se un utente è iscritto oppure no alla newsletter
     */
    public boolean isNewsletter() {
        return isNewsletter;
    }
    
    /**
     * Setter Newsletter
     * @param newsletter parametro di input
     */
    public void setNewsletter(boolean newsletter) {
        isNewsletter = newsletter;
    }
}
