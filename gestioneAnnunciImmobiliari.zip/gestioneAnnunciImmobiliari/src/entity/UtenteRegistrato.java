package entity;

/**
 * Classe entità UtenteRegistrato, classe Parent dell'entità Inserzionsita e UtenteNewsletter
 * @author Pasquale Schioppa
 * @version 14/06/2023
 *
 */

public class UtenteRegistrato {
    private String username;
    private String password;
    private String email;
    
    /**
     * Costruttore classe Parent UtenteRegistrato
     * @param username parametro nome utente
     * @param password parametro password
     * @param email paramentro email
     */
    public UtenteRegistrato(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.email = email;
    }
    	
    /**
     * Getter nome utente
     * @return username restituisce username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Setter nome utente
     * @param username parametro di input
     */
    public void setUsername(String username) {
        this.username = username;
    }
    
    /**
     * Getter password
     * @return password restituisce password
     */
    public String getPassword() {
        return password;
    }
    
    /**
     * Setter password
     * @param password parametro di input
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Getter email
     * @return email restituisce email
     */
    public String getEmail() {
        return email;
    }
    
    /**
     * Setter email
     * @param email parametro di input
     */
    public void setEmail(String email) {
        this.email = email;
    }
}
