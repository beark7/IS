package entity;

	/**
	 * Enumerazione dello stato dell'immobile
	 * @author Pasquale Schioppa
	 * @version 14/06/2023
	 *
	 */
	public enum Stato {
		
		/**
		 * NUOVO enumeration literal che indica lo stato dell'immobile
		 */
		NUOVO,
		
		/**
		 * RISTRUTTURATO enumeration literal che indica lo stato dell'immobile
		 */
	    RISTRUTTURATO;
	}

