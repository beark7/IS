package entity;

/**
 * Enumerazione dello stato dell'immobile
 * @author Pasquale Schioppa
 * @version 14/06/2023
 *
 */

public enum Tipologia {
		
		/**
		 * AFFITTO enumeration literal che indica la tipologia dell'immobile
		 */
        AFFITTO,
        /**
		 * VENDITA enumeration literal che indica la tipologia dell'immobile
		 */
        VENDITA;
}
