package entity;

/**
 * Classe dell'entità Foto
 * @author Pasquale Schioppa
 * @version 14/06/2023
 *
 */

public class Foto {
    private String url;
    private int idFoto;
    private int idAnnuncio;
    
    /**
     * variabile annuncio di tipo Annuncio per accedere all'id annuncio per il costruttore Foto
     */
    private Annuncio annuncio;
    
    /**
     * Costruttore di Foto
     * @param idFoto parametro di input
     * @param idAnnuncio paramentro di input
     * @param url paramentro di input
     */
    public Foto(int idFoto, int idAnnuncio, String url) {
        this.url = url;
        this.idFoto = idFoto;
        this.annuncio = new Annuncio(idAnnuncio);
    }
    
    /**
     * Variante del costruttore Foto per il recuper degli url delle foto
     * @param fotoUrl parametro di input
     */
	 public Foto(String fotoUrl) {
	    this.url = fotoUrl;
	 }
	 
	/**
	 * Getter url foto
	 * @return url restituisce gli url foto
	 */
    public String getUrl() {
        return url;
    }

    /**
     * Setter url foto
     * @param url parametro di input
     */
    public void setUrl(String url) {
        this.url = url;
    }
    
    /**
     * Getter id foto
     * @return idFoto restituisce l'id della foto 
     */
    public int getIdFoto() {
        return idFoto;
    }
    
    /**
     * Setter id foto
     * @param idFoto parametro di input
     */
    public void setIdFoto(int idFoto) {
        this.idFoto = idFoto;
    }
    
    /**
     * Getter dell'istanza di tipo Annuncio
     * @return annuncio istanza di Annuncio
     */
    public Annuncio getAnnuncio() {
    	return annuncio;
    }
    
    /**
     * Setter istanza di tipo Annuncio
     * @param annuncio parametro di input
     */
    public void setAnnuncio(Annuncio annuncio) {
    	this.annuncio = annuncio;
    }
}
