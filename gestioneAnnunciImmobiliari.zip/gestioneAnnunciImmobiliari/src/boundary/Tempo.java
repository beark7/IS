package boundary;

public class Tempo {
    public void inviaNewsletter() {
    }
}

