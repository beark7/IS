package boundary;

public class UtenteRegistrato {
    public void iscrivitiNewsletter() {

    }

    public void disiscrivitiNewsletter() {

    }
}

