 package boundary;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import control.GestioneAnnunci;
import database.AnnuncioDAO;
import database.DBManager;
import entity.Annuncio;
import entity.Stato;
import entity.Tipologia;
import exception.DAOException;
import exception.DBConnectionException;
import exception.OperationException;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * GUI della finestra di dialogo della ricerca degli annunci
 * @author Pasquale Schioppa
 * @version 14/06/2023
 *
 */

public class RicercaAnnuncioGUI {

	JFrame frmRicercaAnnunci;
	private JTextField textCap;
	private JTextField textNumVani;
	database.AnnuncioDAO annuncioDAO;
	static List<Annuncio> results = null;

	/**
	 * Lancia l'applicazione
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RicercaAnnuncioGUI window = new RicercaAnnuncioGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Costruttore della classe senza parametri
	 * @throws SQLException eccezione per la gestione degli errore sulle operazioni delle query
	 */
	
	public RicercaAnnuncioGUI() throws SQLException {
		initialize();
		textCap.setText("80100");
		textNumVani.setText("3");
	}
	
	/**
	 * Funzione Helper per il check se un numero è un Integer
	 * @param input numero da controllare
	 * @return booleano vero o falso
	 */
	
	public static boolean isInteger(String input) {
        try {
            Integer.parseInt(input);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

	/**
	 * Inizializzazione dei componenti della UI
	 */
	private void initialize() {
		GestioneAnnunci gestioneAnnunci = GestioneAnnunci.getInstance();
		
		frmRicercaAnnunci = new JFrame();
		frmRicercaAnnunci.setTitle("Ricerca Annunci");
		frmRicercaAnnunci.setBounds(100, 100, 496, 390);
		frmRicercaAnnunci.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmRicercaAnnunci.getContentPane().setLayout(null);
		
		JLabel lblParametriRicerca = new JLabel("Inserisci i parametri di ricerca");
		lblParametriRicerca.setBounds(110, 23, 259, 28);
		lblParametriRicerca.setFont(new Font("Segoe UI", Font.BOLD, 18));
		lblParametriRicerca.setHorizontalAlignment(SwingConstants.CENTER);
		frmRicercaAnnunci.getContentPane().add(lblParametriRicerca);
		
		JLabel lblTipologia = new JLabel("Tipologia:");
		lblTipologia.setBounds(132, 79, 65, 29);
		lblTipologia.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		frmRicercaAnnunci.getContentPane().add(lblTipologia);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(238, 83, 100, 25);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Affitto", "Vendita"}));
		frmRicercaAnnunci.getContentPane().add(comboBox);
		
		JLabel lblStato = new JLabel("Stato:");
		lblStato.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblStato.setBounds(132, 129, 46, 29);
		frmRicercaAnnunci.getContentPane().add(lblStato);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Nuovo", "Ristrutturato"}));
		comboBox_1.setBounds(238, 133, 100, 25);
		frmRicercaAnnunci.getContentPane().add(comboBox_1);
		
		JLabel lblCap = new JLabel("CAP:");
		lblCap.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblCap.setBounds(132, 181, 46, 14);
		frmRicercaAnnunci.getContentPane().add(lblCap);
		
		textCap = new JTextField();
		textCap.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		textCap.setBounds(238, 177, 100, 25);
		frmRicercaAnnunci.getContentPane().add(textCap);
		textCap.setColumns(10);
		
		JLabel lblNumVani = new JLabel("Numero Vani");
		lblNumVani.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblNumVani.setBounds(132, 232, 92, 14);
		frmRicercaAnnunci.getContentPane().add(lblNumVani);
		
		textNumVani = new JTextField();
		textNumVani.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		textNumVani.setBounds(238, 228, 100, 25);
		frmRicercaAnnunci.getContentPane().add(textNumVani);
		textNumVani.setColumns(10);
		
		
		JButton btnRicerca = new JButton("Ricerca");
		btnRicerca.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				boolean isValid = true;
				String capInput = textCap.getText().trim();
				String numVaniInput = textNumVani.getText().trim();
				
				//effettuo i controlli sui text field
				if (capInput.isEmpty()) {
		            JOptionPane.showMessageDialog(null, "Inserisci un valore nel campo CAP.");
		            isValid = false;
		        } else if (!isInteger(capInput)) {
		            JOptionPane.showMessageDialog(null, "Inserisci solo numeri interi nel campo CAP.");
		            isValid = false;
		        } else if (capInput.length() != 5) {
                    JOptionPane.showMessageDialog(null, "Il CAP deve essere esattamente di 5 caratteri.");
                    isValid = false;
                }
				if (numVaniInput.isEmpty()) {
		            JOptionPane.showMessageDialog(null, "Inserisci un valore nel campo Numero Vani.");
		            isValid = false;
		        } else if (!isInteger(numVaniInput)) {
		            JOptionPane.showMessageDialog(null, "Inserisci solo numeri interi nel campo Numero Vani.");
		            isValid = false;
		        } else {
                    int numVani = Integer.parseInt(numVaniInput);
                    if (numVani == 0) {
                        JOptionPane.showMessageDialog(null, "Il Numero Vani non può essere 0.");
                        isValid = false;
                    } 
                }
				
		        if(isValid){
						try {
							//effettuo la ricerca degli annunci prendendo i paramentri di ricerca dalla UI
							results = gestioneAnnunci.ricercaAnnuncio(
									Tipologia.valueOf(comboBox.getSelectedItem().toString().toUpperCase()),
									Stato.valueOf(comboBox_1.getSelectedItem().toString().toUpperCase()),
									textCap.getText(),
									Integer.parseInt(textNumVani.getText()));
									
									System.out.println(results);
					
									AnnunciGUI risultatiGUI = new AnnunciGUI(results);

									risultatiGUI.annunciFrame.setVisible(true);
									frmRicercaAnnunci.setVisible(false);
		
						} catch (DAOException e1) {
							JOptionPane.showMessageDialog(null, "Errore con il DAO.");
							e1.printStackTrace();
						} catch (DBConnectionException e1) {
							JOptionPane.showMessageDialog(null, "Errore di connessione al DB.");
							e1.printStackTrace();
						} catch (OperationException e2) {
							JOptionPane.showMessageDialog(null, "Errore.");
						} catch (NumberFormatException e1) {
							e1.printStackTrace();
						} catch (SQLException e1) {
							JOptionPane.showMessageDialog(null, "Errore della SQL.");
							e1.printStackTrace();
						} 
				}
			}
		});
		btnRicerca.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		btnRicerca.setBounds(281, 287, 110, 35);
		frmRicercaAnnunci.getContentPane().add(btnRicerca);
		
		JButton btnIndietro = new JButton("Indietro");
		btnIndietro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmRicercaAnnunci.setVisible(false);
				MainGUI.frmAnnunciImmobiliari.setVisible(true);	
			}
		});
		btnIndietro.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		btnIndietro.setBounds(110, 287, 110, 35);
		frmRicercaAnnunci.getContentPane().add(btnIndietro);
	}
}
