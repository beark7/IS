package boundary;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * Applicazione Gestione Annunci Immobiliari
 * @author Pasquale Schioppa
 * @version 14/06/2023
 *
 */

public class MainGUI {

	static JFrame frmAnnunciImmobiliari;

	/**
	 * Lancio l'applicazione
	 * @param args per il metodo main
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainGUI window = new MainGUI();
					window.frmAnnunciImmobiliari.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Costruttore della classe senza parametro
	 */
	public MainGUI() {
		initialize();
	}

	/**
	 * Inizializza la i componenti della UI
	 */
	
	private void initialize() {
		frmAnnunciImmobiliari = new JFrame();
		frmAnnunciImmobiliari.setTitle("Annunci Immobiliari");
		frmAnnunciImmobiliari.setBounds(100, 100, 450, 285);
		frmAnnunciImmobiliari.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAnnunciImmobiliari.getContentPane().setLayout(null);
		
		JLabel lblBenvenuto = new JLabel("Annunci Immobiliari");
		lblBenvenuto.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblBenvenuto.setHorizontalAlignment(SwingConstants.CENTER);
		lblBenvenuto.setBounds(137, 36, 160, 30);
		frmAnnunciImmobiliari.getContentPane().add(lblBenvenuto);
		
		JButton btnEffettuaRegistrazione = new JButton("Effettua Registrazione");
		btnEffettuaRegistrazione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Funzione attualmente non disponibile");
			}
		});
		btnEffettuaRegistrazione.setBounds(137, 136, 160, 35);
		frmAnnunciImmobiliari.getContentPane().add(btnEffettuaRegistrazione);
		
		JButton btnNewButton = new JButton("Ricerca Annunci");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					RicercaAnnuncioGUI ricercaWindow = new RicercaAnnuncioGUI();
					ricercaWindow.frmRicercaAnnunci.setVisible(true);
					frmAnnunciImmobiliari.setVisible(false);
					
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "Impossibile accedere alla funzione di Ricerca");
				}
			}
		});
		btnNewButton.setBounds(137, 90, 160, 35);
		frmAnnunciImmobiliari.getContentPane().add(btnNewButton);
	}
}
