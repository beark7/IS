package boundary;

public class Utente {
    public void effettuaRegistrazione() {
    	
    }

    public void visualizzaDettagliAnnuncio(int idAnnuncio) {
  
    }

    public void ricercaAnnuncio(String criterioRicerca) {
        
    }
}

