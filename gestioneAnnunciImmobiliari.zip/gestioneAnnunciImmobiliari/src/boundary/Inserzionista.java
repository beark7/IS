package boundary;

public class Inserzionista {
    public void effettuaRegistrazione() {
    	
    }

    public void pubblicaAnnuncio() {

    }

    public void modificaAnnuncio() {
       
    }

    public void eliminaAnnuncio() {
        
    }
}

