package boundary;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;

import database.DBManager;
import database.InserzionistaDAO;
import entity.Annuncio;
import entity.Foto;
import entity.Inserzionista;
import exception.DAOException;
import exception.DBConnectionException;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

import control.GestioneAnnunci;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;

/**
 * GUI degli annunci trovati
 * @author Pasquale Schioppa
 * @version 14/06/2023
 *
 */

public class AnnunciGUI {
	
	/**
	 * @param resulAnnunci lista di "Annuncio" contenenti gli annunci.
	 */
	
	JFrame annunciFrame;
	public static JTable tableAnnunciRisultati;
	static List<Annuncio> results;
	JLabel lblRecapito;
	public static JLabel lblMostraRecapito;
	public static JLabel lblMostraFoto;
	public static List<Annuncio> resultAnnunci;

	/**
	 * Lancia l'applicazione.
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AnnunciGUI window = new AnnunciGUI();
					window.annunciFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Costruttore della classe senza parametri
	 */
	public AnnunciGUI() {
		resultAnnunci = Collections.emptyList();
		initialize();
	}
	
	/**
	 * Costruttore della classe con parametro una lista di di tipo "Annuncio"
	 * @param resultAnnunci paramentro di input tipo Lista Annuncio
	 */
	
	public AnnunciGUI(List<Annuncio> resultAnnunci) {
		this.resultAnnunci = resultAnnunci;
		initialize();
	}

	/**
	 * Inizializza i componenti della UI
	 */
	private void initialize() {
		annunciFrame = new JFrame();
		annunciFrame.setTitle("Annunci");
		annunciFrame.setBounds(100, 100, 1300, 572);
		annunciFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		annunciFrame.getContentPane().setLayout(null);
		
		DefaultTableModel tableModel = new DefaultTableModel();
		tableModel.addColumn("Annuncio");
		tableModel.addColumn("Inserzionista");
		tableModel.addColumn("Prezzo");
		tableModel.addColumn("Data Inserimento");
		tableModel.addColumn("CAP");
		tableModel.addColumn("Metri Quadri");
		tableModel.addColumn("Vani");
		tableModel.addColumn("Descrizione");
		tableModel.addColumn("Stato");
		tableModel.addColumn("Tipologia");
				
		// Aggiunta dei risultati al modello di dati della tabella
		 for (Annuncio annuncio : resultAnnunci) {
            Object[] rowData = {annuncio.getIdAnnuncio(), annuncio.getIdInserzionista(), annuncio.getPrezzo(), annuncio.getDataInserimento(),
            					annuncio.getCap(),annuncio.getNumMetriQuadri(), annuncio.getNumVani(), annuncio.getDescrizione(),
            					annuncio.getTipologia(), annuncio.getStato()};
            tableModel.addRow(rowData);
        }
	
		tableAnnunciRisultati = new JTable(tableModel);
		
		JScrollPane scrollPane = new JScrollPane(tableAnnunciRisultati);
		scrollPane.setBounds(10, 72, 1264, 275);
		annunciFrame.getContentPane().add(scrollPane);

		//Visualizzo i dettagli annunci selezionando la singola riga della tabella
		tableAnnunciRisultati.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				GestioneAnnunci gestioneAnnunci = GestioneAnnunci.getInstance();
				gestioneAnnunci.visualizzaDettagliAnnuncio();
				
			}
		});
		scrollPane.setViewportView(tableAnnunciRisultati);
		
		JLabel lblNewLabel = new JLabel("Annunci trovati: ");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
		lblNewLabel.setBounds(562, 24, 160, 25);
		annunciFrame.getContentPane().add(lblNewLabel);
		
		JButton btnIndietro = new JButton("Indietro");
		btnIndietro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					RicercaAnnuncioGUI ricercaAnnuncioGUI = new RicercaAnnuncioGUI();
					ricercaAnnuncioGUI.frmRicercaAnnunci.setVisible(true);
					annunciFrame.setVisible(false);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}		
			}
		});
		btnIndietro.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		btnIndietro.setBounds(10, 477, 120, 30);
		annunciFrame.getContentPane().add(btnIndietro);
		
		lblRecapito = new JLabel("Recapito Inserzionista:");
		lblRecapito.setFont(new Font("Segoe UI", Font.BOLD, 12));
		lblRecapito.setBounds(10, 375, 138, 25);
		annunciFrame.getContentPane().add(lblRecapito);
		
		lblMostraRecapito = new JLabel("");
		lblMostraRecapito.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblMostraRecapito.setBounds(145, 376, 108, 25);
		annunciFrame.getContentPane().add(lblMostraRecapito);
		
		JLabel lblFoto = new JLabel("Foto Annuncio: ");
		lblFoto.setFont(new Font("Segoe UI", Font.BOLD, 12));
		lblFoto.setBounds(10, 433, 126, 14);
		annunciFrame.getContentPane().add(lblFoto);
		
		lblMostraFoto = new JLabel("");
		lblMostraFoto.setVerticalAlignment(SwingConstants.TOP);
		lblMostraFoto.setHorizontalAlignment(SwingConstants.LEFT);
		lblMostraFoto.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblMostraFoto.setBounds(145, 434, 661, 73);
		annunciFrame.getContentPane().add(lblMostraFoto);
	}
}
