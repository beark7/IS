package database;

import entity.Annuncio;
import entity.Foto;
import entity.Stato;
import entity.Tipologia;
import exception.DAOException;
import exception.DBConnectionException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableModel;
import javax.swing.table.DefaultTableModel;

import boundary.AnnunciGUI;

/**
 * DAO della classe Annuncio
 * @author Pasquale Schioppa
 * @version 14/06/2023
 *
 */
public class AnnuncioDAO {
	
	/**
	 * parametri di input della funzione readAnnunci
	 * @param tipologia di tipo Tipologia per filtrare la ricerca
	 * @param stato di tipo Stato per filtrare la ricerca
	 * @param cap di tipo String per filtrare la ricerca
	 * @param numVani di tipo int per filtrare la ricerca
	 * @return annunci lista di annunci letti nel database
	 */
	public static List<Annuncio> readAnnunci(Tipologia tipologia, Stato stato, String cap, int numVani) {
	    List<Annuncio> annunci = new ArrayList<>();

	    try {
	        Connection connection = DBManager.getConnection();
	        String query = "SELECT * FROM Annuncio WHERE tipologia = ? AND stato = ? AND cap = ? AND numVani = ?;";
	        PreparedStatement preparedStatement = connection.prepareStatement(query);

	        // Imposto i valori dei parametri nel PreparedStatement
	        preparedStatement.setString(1, tipologia.toString());
	        preparedStatement.setString(2, stato.toString());
	        preparedStatement.setString(3, cap);
	        preparedStatement.setInt(4, numVani);
	        
	        System.out.println(preparedStatement.toString()); 
	        
	        ResultSet resultSet = preparedStatement.executeQuery();
	        

	        while (resultSet.next()) {
	            // Leggo i dati dal ResultSet
	            int idAnnuncio = resultSet.getInt("IDAnnuncio");
	            int idInserzionista = resultSet.getInt("IDInserzionista");
	            int annNumVani = resultSet.getInt("numVani");
	            float prezzo = resultSet.getFloat("prezzo");
	            Date dataInserimento = resultSet.getDate("dataInserimento");
	            String annCap = resultSet.getString("cap");
	            float numMetriQuadri = resultSet.getFloat("numMetriQuadri");
	            String descrizione = resultSet.getString("descrizione");       
	            String annStato = resultSet.getString("stato");
	            String annTipologia = resultSet.getString("tipologia");
	            List<Foto> listaFoto = FotoDAO.readFoto(idAnnuncio);
 
	            try {
	            	 // Creo oggetto Annuncio
		            Annuncio annuncio = new Annuncio(idAnnuncio, idInserzionista, prezzo, dataInserimento, annCap, numMetriQuadri,
		            		annNumVani, descrizione, Stato.valueOf(annStato), listaFoto , Tipologia.valueOf(annTipologia));
		            
		            System.out.println(annuncio);
		            
		         // Aggiungo annuncio alla lista risultato
		            annunci.add(annuncio);
		            		            
				} catch (IllegalArgumentException | NullPointerException  e) {
					System.out.println("Errore nella creazione dell'oggetto Annuncio");
				} 
	        }
	        
	        resultSet.close();
	        preparedStatement.close();
	        connection.close();
	    } catch (SQLException | DBConnectionException | DAOException e) {
	        e.printStackTrace();
	    }

	    return annunci;
	}	
}
