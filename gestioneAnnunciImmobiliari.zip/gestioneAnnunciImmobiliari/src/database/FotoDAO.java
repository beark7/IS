package database;

import entity.Foto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import exception.DAOException;
import exception.DBConnectionException;	

/**
 * DAO della classe Foto
 * @author Pasquale Schioppa
 * @version 14/06/2023
 *
 */

public class FotoDAO {
	
	/**
	 * Funzione DAO per la lettura delle foto dal database
	 * @param idAnnuncio parametro di input
	 * @return listaFoto restitusice una lista di foto
	 * @throws DAOException eccezione DAO
	 * @throws DBConnectionException eccezione per la connesione al DB
	 */
	public static List<Foto> readFoto(int idAnnuncio) throws DAOException, DBConnectionException {
		List<Foto> listaFoto = new ArrayList<>();

		try {

			Connection conn = DBManager.getConnection();

			String query = "SELECT * FROM Foto WHERE IDAnnuncio=? LIMIT 8;";

			try {
				PreparedStatement stmt = conn.prepareStatement(query);
				stmt.setInt(1, idAnnuncio);
				
				ResultSet result = stmt.executeQuery();

				while (result.next()) {
					Foto foto = new Foto(result.getInt("IDFoto"), result.getInt("IDAnnuncio"), result.getString("url"));
					listaFoto.add(foto);
				}
				
			}catch(SQLException e) {
				throw new DAOException("Errore nel recuperare le foto");
			} finally {
				DBManager.closeConnection();
			}

		}catch(SQLException e) {
			throw new DBConnectionException("Errore di connessione al DB");
		}

		return listaFoto;
	}
  
}
