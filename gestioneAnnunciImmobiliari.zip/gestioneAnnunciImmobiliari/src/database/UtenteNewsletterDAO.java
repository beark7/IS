package database;

import entity.UtenteNewsletter;
import java.util.ArrayList;
import java.util.List;

public class UtenteNewsletterDAO {
  

}
