package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Classe per la gestione della connessione al DB
 * @author Pasquale Schioppa
 * @version 14/06/2023
 *
 */

public class DBManager {
	
	private static Connection conn = null;
	
	/**
	 * Costruttore della classe
	 */
	private DBManager() {}
	
	/**
	 * Getter della connesione (se già esistente)
	 * @return conn restituisce la connesione
	 */
	public static Connection getConnection() {
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/appannunci", "root", "");
			System.out.println("connesso");
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return conn;
	}
	
	/**
	 * Chiude la connesione con il DB
	 * @throws SQLException eccezione per operazioni sulla query
	 */
	public static void closeConnection() throws SQLException {
		
			if(conn != null) {
				conn.close();
			}
	}
}
