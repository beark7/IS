package database;

import entity.Newsletter;
import java.util.ArrayList;
import java.util.List;

public class NewsletterDAO {
    

}
