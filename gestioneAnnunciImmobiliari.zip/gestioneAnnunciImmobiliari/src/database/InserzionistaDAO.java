package database;

import entity.Inserzionista;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import exception.DAOException;
import exception.DBConnectionException;	

/**
 * DAO della classe Inserzionista
 * @author Pasquale Schioppa
 * @version 14/06/2023
 *
 */

public class InserzionistaDAO {
	
    /**
     * Funzione DAO per la lettura dell'inserzionista dal database
     * @param idIns parametro di input
     * @return ins id inserzionista
     * @throws DAOException eccezione DAO
     * @throws DBConnectionException eccezione per la connesione al DB
     */
	public static Inserzionista readInserzionista(int idIns) throws DAOException, DBConnectionException {
		
		Inserzionista ins = null;
		try {

			Connection conn = DBManager.getConnection();
			String query = "SELECT * FROM Inserzionista WHERE IDInserzionista=?;";

			try {
				PreparedStatement stmt = conn.prepareStatement(query);				
				stmt.setInt(1, idIns);				
				System.out.println(stmt.toString());
				ResultSet result = stmt.executeQuery();

				if(result.next()) {
					ins = new Inserzionista(null, null, null, result.getString("telefono"), result.getInt("IDInserzionista"));	
				}
			}catch(SQLException e) {
				System.err.println(e.toString());
				throw new DAOException("Errore nel recuperare inserzionista");
			} finally {
				DBManager.closeConnection();
			}
		}catch(SQLException e) {
			throw new DBConnectionException("Errore di connessione al DB");
		}
		return ins;
	} 
}
