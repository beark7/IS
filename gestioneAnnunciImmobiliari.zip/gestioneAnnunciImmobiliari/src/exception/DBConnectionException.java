package exception;

/**
 * DBConnectionException, classe per la gestione delle eccezioni della connessione al database
 * @author Pasquale Schioppa
 * @version 14/06/2023
 *
 */

public class DBConnectionException extends Exception {
	
	/**
	 * Costruttore della classe
	 */
	public DBConnectionException() {}
	
	/**
	 * Variante del costruttore
	 * @param msg paramentro di input
	 */
	public DBConnectionException(String msg) {
		super(msg);
	}
}
