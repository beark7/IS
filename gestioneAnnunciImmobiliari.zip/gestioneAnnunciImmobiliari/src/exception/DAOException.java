package exception;

/**
 * DAOException, classe per la gestione delle eccezioni dalle classi DAO
 * @author Pasquale Schioppa
 * @version 14/06/2023
 *
 */
public class DAOException extends Exception {
	
	/**
	 * Costruttore della classe
	 */
	public DAOException() {}
	
	/**
	 * Variante del costruttore della classe
	 * @param object parametro di input
	 */
	public DAOException(Object object) {
		super();
	}
}
