package exception;

/**
 * OperationException, classe per la gestione delle eccezioni per le operazioni
 * @author Pasquale Schioppa
 * @version 14/06/2023
 *
 */

public class OperationException extends Exception {
	/**
	 * Costruttore della classe
	 */
	public OperationException() {}
	
	/**
	 * Variante del costruttore
	 * @param msg parametro di input
	 */
	public OperationException(String msg) {
		super(msg);
	}
}
