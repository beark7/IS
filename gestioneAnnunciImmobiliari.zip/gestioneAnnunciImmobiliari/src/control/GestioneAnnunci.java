package control;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import boundary.AnnunciGUI;
import database.AnnuncioDAO;
import database.InserzionistaDAO;
import entity.Annuncio;
import entity.Foto;
import entity.Inserzionista;
import entity.Stato;
import entity.Tipologia;
import exception.DAOException;
import exception.DBConnectionException;
import exception.OperationException;

/**
 * Classe Gestione Annunci, Controller
 * @author Pasquale Schioppa
 * @version 14/06/2023
 *
 */

public class GestioneAnnunci {
    private static GestioneAnnunci gAinstance = null;
    private List<Annuncio> annunci;
    
    /**
     * Costruttore della classe senza parametri
     */
    private GestioneAnnunci() {
    }
    
    /**
     * Singleton del Controller
     * @return gAinstance instanza del Controller "GestioneAnnunci" se già allocato.
     */
    //Singleton
    public static GestioneAnnunci getInstance() {
        if (gAinstance == null) {
        	gAinstance = new GestioneAnnunci();
        }
        return gAinstance;
    }
    
    /**
     * Metodo ricercaAnnuncio, utilizza dall'utente boundary per effettuare e filtrare la ricerca di un annuncio immobiliare.
     * @param tipologia di tipo Tipologia, parametro di input della funzione ricercaAnnuncio()
     * @param stato di tipo Stato, parametro di input della funzione ricercaAnnuncio()
     * @param cap di tipo Strin, parametro di input della funzione ricercaAnnuncio()
     * @param numVani di tipo int, parametro di input della funzione ricercaAnnuncio()
     * @return annunci la lista degli annunci trovati
     * @throws OperationException eccezione operation
     * @throws DBConnectionException eccezione per la connesione al DB
     * @throws DAOException eccezione per le operazioni con il DAO
     * @throws SQLException eccezione per le operazioni sulle quey
     */
    public List<Annuncio> ricercaAnnuncio(Tipologia tipologia, Stato stato, String cap, int numVani) throws OperationException,DBConnectionException,DAOException, SQLException {
          	
    	try {
    		annunci = AnnuncioDAO.readAnnunci(tipologia, stato,cap, numVani);
    		System.out.println(annunci);
    		if(annunci == null) {
    			throw new OperationException("Annuncio non trovato");
    		}
			
		}catch(OperationException dbex)  {			
			throw new DBConnectionException("\nRiscontrato problema interno applicazione!\n");
		} 
    	
    	return annunci;
    }
    
    /**
     * il metodo visualizza i dettagli del singolo annuncio.
     */
    public void visualizzaDettagliAnnuncio() {
    	
    	int riga = AnnunciGUI.tableAnnunciRisultati.getSelectedRow();
    	Annuncio selected = AnnunciGUI.resultAnnunci.get(riga);
    	
    	System.out.println(selected.getFoto());
		
		try {
			
			//prendo l'indice dell'inserzionista dalla riga selezionata, leggo con la relativa classe DAO e lo stampo nel label della UI
			Inserzionista ins = InserzionistaDAO.readInserzionista(selected.getIdInserzionista());
			AnnunciGUI.lblMostraRecapito.setText(ins.getTelefono());
			
			//crea una lista di urlFoto, una volta selezionata la riga ciclo per tutte le foto e le aggiungo alla lista
			List<String> urlFoto = new ArrayList<>();
			
			for (Foto f : selected.getFoto()) {
				urlFoto.add(f.getUrl());
			}
			//stampo la lista foto nella UI
			AnnunciGUI.lblMostraFoto.setText(String.join(", ", urlFoto));
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}       
    } 
}

